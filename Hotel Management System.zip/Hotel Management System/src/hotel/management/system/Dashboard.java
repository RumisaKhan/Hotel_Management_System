/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.management.system;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


public class Dashboard extends JFrame implements ActionListener{
   
    
    public Dashboard() {
        super("HOTEL MANAGEMENT SYSTEM");
	
        setForeground(Color.CYAN);
        setLayout(null); 

        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/third.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1950, 1000,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2); 
	JLabel NewLabel = new JLabel(i3);
	NewLabel.setBounds(0, 0, 1950, 1000); 
        add(NewLabel);
        
        JLabel l1= new JLabel("THE ROYAL TAJ GROUP WELCOMES YOU");
	l1.setForeground(Color.WHITE);
        l1.setFont(new Font("Tahoma", Font.PLAIN, 46));
	l1.setBounds(300, 40, 1000, 50);
	NewLabel.add(l1);
		
      
        JMenuBar menuBar = new JMenuBar();
	setJMenuBar(menuBar);
		
        JMenu m1= new JMenu("HOTEL MANAGEMENT");
        m1.setForeground(Color.BLUE);
       menuBar.add(m1);
       m1.addActionListener(this);
		
        JMenuItem mi1= new JMenuItem("RECEPTION");
	m1.add(mi1);
        mi1.addActionListener(this);
		
	JMenu m2 = new JMenu("ADMIN");
        m2.setForeground(Color.RED);
	menuBar.add(m2);
        m2.addActionListener(this);
        
        JMenuItem mi2 = new JMenuItem("ADD EMPLOYEE");
	m2.add(mi2);
        mi2.addActionListener(this);
  

        JMenuItem mi3= new JMenuItem("ADD ROOMS");
	m2.add(mi3);
        mi3.addActionListener(this);
           
        
        JMenuItem mi4 = new JMenuItem("ADD DRIVERS");
	m2.add(mi4);
        mi4.addActionListener(this);
	
         
         setLayout(null);
        setBounds(0,0,1950,1020);
        setVisible(true);
    }
      
        
            
            public void actionPerformed(ActionEvent ae){
                if(ae.getActionCommand().equals("RECEPTION")){
                    new Reception().setVisible(true);
                } else if(ae.getActionCommand().equals("ADD EMPLOYEE")){
                new AddEmployee().setVisible(true);
      }else if(ae.getActionCommand().equals("ADD ROOMS")){
          new AddRoom().setVisible(true);
      }else if(ae.getActionCommand().equals("ADD DRIVERS")){
          new AddDrivers().setVisible(true);
          
      }
        }
     public static void main(String[] args) {
        new Dashboard().setVisible(true);
    }

}
