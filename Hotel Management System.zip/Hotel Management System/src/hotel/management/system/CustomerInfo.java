package hotel.management.system;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import java.sql.*;	
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerInfo extends JFrame  implements ActionListener{
	
	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblJob;
	private JLabel lblName;
	private JLabel lblDepartment;
 
        JButton btnLoadData;
        JButton btnExit;
	
	public CustomerInfo()  {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250, 150, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBounds(0, 34, 1000, 450);
		contentPane.add(table);
		
		 btnLoadData = new JButton("Load Data");
                btnLoadData.addActionListener(this);
					
		btnLoadData.setBounds(350, 500, 120, 30);
                btnLoadData.setBackground(Color.BLACK);
                btnLoadData.setForeground(Color.WHITE);
		contentPane.add(btnLoadData);
		
		  btnExit = new JButton("Back");
                  btnExit.addActionListener(this);
		
		btnExit.setBounds(510, 500, 120, 30);
                btnExit.setBackground(Color.BLACK);
                btnExit.setForeground(Color.WHITE);
		contentPane.add(btnExit);
		
		lblNewLabel = new JLabel("Document Type");
		lblNewLabel.setBounds(10, 10, 100, 20);
		contentPane.add(lblNewLabel);
		
		lblJob = new JLabel("Number");
		lblJob.setBounds(160, 10, 70, 14);
		contentPane.add(lblJob);
		
		lblName = new JLabel("Name");
		lblName.setBounds(273, 11, 70, 14);
		contentPane.add(lblName);
		
		lblDepartment = new JLabel("Gender");
		lblDepartment.setBounds(416, 11, 70, 14);
		contentPane.add(lblDepartment);
                
                JLabel l1 = new JLabel("Country");
		l1.setBounds(536, 11, 70, 14);
		contentPane.add(l1);
                
                JLabel l2 = new JLabel("Room Number");
		l2.setBounds(656, 11, 86, 14);
		contentPane.add(l2);
                
                JLabel l3 = new JLabel("Status");
		l3.setBounds(786, 11, 70, 14);
		contentPane.add(l3);
                
                JLabel l4 = new JLabel("Deposit");
		l4.setBounds(896, 11, 70, 14);
		contentPane.add(l4);
                
                getContentPane().setBackground(Color.WHITE);
	}
    public void actionPerformed(ActionEvent ae){
           
           
            if(ae.getSource()== btnLoadData ){
         
                  try{
                                conn c = new conn();
				String str = "select * from customer";
				ResultSet rs = c.s.executeQuery(str);
				table.setModel(DbUtils.resultSetToTableModel(rs));
			}
				catch(Exception e1){
				e1.printStackTrace();
				}
			}
			
               
             else if(ae.getSource()== btnExit ){
               new Reception().setVisible(true);
              this.setVisible(false);
         }
}
       public static void main(String[] args)  {
            new CustomerInfo().setVisible(true);
        }
}