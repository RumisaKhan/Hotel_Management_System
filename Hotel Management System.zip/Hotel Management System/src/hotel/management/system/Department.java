/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.management.system;

import java.awt.BorderLayout;
import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTable;
import java.sql.*;	
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Department extends JFrame implements ActionListener {
	Connection conn = null;
	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
        JButton btnNewButton_1 ;
        JButton btnNewButton ;

	public Department() throws SQLException {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 150, 700, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable();
		table.setBounds(0, 40, 700, 350);
		contentPane.add(table);
		
		btnNewButton = new JButton("Load Data");
                btnNewButton.addActionListener(this);
		
		btnNewButton.setBounds(170, 410, 120, 30);
                btnNewButton.setBackground(Color.BLACK);
                btnNewButton.setForeground(Color.WHITE);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Back");
                btnNewButton_1.addActionListener(this);
		
		btnNewButton_1.setBounds(400, 410, 120, 30);
                btnNewButton_1.setBackground(Color.BLACK);
                btnNewButton_1.setForeground(Color.WHITE);
		contentPane.add(btnNewButton_1);
		
		lblNewLabel = new JLabel("Department");
		lblNewLabel.setBounds(145, 11, 105, 14);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Budget");
		lblNewLabel_1.setBounds(431, 11, 75, 14);
		contentPane.add(lblNewLabel_1);
                
                getContentPane().setBackground(Color.WHITE);
	}
        public void actionPerformed(ActionEvent ae){
            if(ae.getSource()== btnNewButton){
                	String displayCustomersql = "select * from Department";
                try{
                                    conn c = new conn();
                                        ResultSet rs = c.s.executeQuery(displayCustomersql);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
					
				}
				catch (Exception e1){
					System.out.println(e1);
				}
				

            }else if(ae.getSource() == btnNewButton_1){
                new Reception().setVisible(true);
                this.setVisible(false);
            }
           
        }
public static void main(String[] args) throws SQLException{
    new Department().setVisible(true);
}
}