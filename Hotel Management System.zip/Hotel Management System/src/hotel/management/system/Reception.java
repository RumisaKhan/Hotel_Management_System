/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotel.management.system;

import javax.swing.*;

import java.sql.*;	
import java.awt.event.*;
import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Reception extends JFrame implements ActionListener{

	private JPanel contentPane;


    JButton
btnNewCustomerForm,
    btnNewButton,
     btnNewButton_1,
    btnNewButton_2,
    btnNewButton_3,
     btnManagerInfo,
     btnNewButton_4,
    btnNewButton_5,
     btnSearchRoom,
     btnNewButton_7,
     btnPickUpService,
    btnNewButton_6;

	
	
	public Reception(){
		
                setBounds(320, 150, 850, 570);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(null);
                
                ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("hotel/management/system/icons/fourth.jpg"));
                Image i3 = i1.getImage().getScaledInstance(500, 500,Image.SCALE_DEFAULT);
                ImageIcon i2 = new ImageIcon(i3);
                JLabel l1 = new JLabel(i2);
                l1.setBounds(250,30,500,470);
                add(l1);
		
		
                    btnNewCustomerForm= new JButton("New Customer Form");
                   btnNewCustomerForm.addActionListener(this);
               
		
		btnNewCustomerForm.setBounds(10, 30, 200, 30);
                btnNewCustomerForm.setBackground(Color.BLACK);
                btnNewCustomerForm.setForeground(Color.WHITE);
		contentPane.add(btnNewCustomerForm);
		
		 btnNewButton = new JButton("Room");
                btnNewButton.addActionListener(this);
		
		btnNewButton.setBounds(10, 70, 200, 30);
                btnNewButton.setBackground(Color.BLACK);
                btnNewButton.setForeground(Color.WHITE);

		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Department");
                btnNewButton_1.addActionListener(this);
		btnNewButton_1.setBounds(10, 110, 200, 30);
                btnNewButton_1.setBackground(Color.BLACK);
                btnNewButton_1.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("All Employee Info");
                btnNewButton_2.addActionListener(this);
		
		btnNewButton_2.setBounds(10, 150, 200, 30);                
                btnNewButton_2.setBackground(Color.BLACK);
                btnNewButton_2.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_2);
		
	         btnNewButton_3 = new JButton("Customer Info");
                 btnNewButton_3.addActionListener(this);
		
		btnNewButton_3.setBounds(10, 190, 200, 30);
                btnNewButton_3.setBackground(Color.BLACK);
                btnNewButton_3.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_3);
		
		btnManagerInfo = new JButton("Manager Info");
                btnManagerInfo.addActionListener(this);
		
		btnManagerInfo.setBounds(10, 230, 200, 30);
                btnManagerInfo.setBackground(Color.BLACK);
                btnManagerInfo.setForeground(Color.WHITE);

		contentPane.add(btnManagerInfo);
		
	        btnNewButton_4 = new JButton("Check Out");
                btnNewButton_4.addActionListener(this);
		
		btnNewButton_4.setBounds(10, 270, 200, 30);
                btnNewButton_4.setBackground(Color.BLACK);
                btnNewButton_4.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_4);
		
		btnNewButton_5 = new JButton("Update Check Status");
                btnNewButton_5.addActionListener(this);
	
		
		btnNewButton_5.setBounds(10, 310, 200, 30);
                btnNewButton_5.setBackground(Color.BLACK);
                btnNewButton_5.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("Update Room Status");
                 btnNewButton_6.addActionListener(this);
		
		btnNewButton_6.setBounds(10, 350, 200, 30);
                btnNewButton_6.setBackground(Color.BLACK);
                btnNewButton_6.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_6);
		
		
                btnPickUpService = new JButton("Pick up Service");
                btnPickUpService.addActionListener(this); 
		btnPickUpService.setBounds(10, 390, 200, 30);
                btnPickUpService.setBackground(Color.BLACK);
                btnPickUpService.setForeground(Color.WHITE);

		contentPane.add(btnPickUpService);
		
		 btnSearchRoom = new JButton("Search Room");
                btnSearchRoom.addActionListener(this);
		btnSearchRoom.setBounds(10, 430, 200, 30);
                btnSearchRoom.setBackground(Color.BLACK);
                btnSearchRoom.setForeground(Color.WHITE);

		contentPane.add(btnSearchRoom);

		 btnNewButton_7 = new JButton("Log Out");
                btnNewButton_7.addActionListener(this);
		
                
		btnNewButton_7.setBounds(10, 470, 200, 30);
                btnNewButton_7.setBackground(Color.BLACK);
                btnNewButton_7.setForeground(Color.WHITE);

		contentPane.add(btnNewButton_7);
                getContentPane().setBackground(Color.WHITE);
                
                setVisible(true);
	}
        public void actionPerformed(ActionEvent ae){
           
           
            if(ae.getSource()==btnNewCustomerForm){
                try {
                    new NewCustomer().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            } else if(ae.getSource()==btnNewButton){
                
                try {
                    new Room().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
         
                    this.setVisible(false);
                
                
            } else if(ae.getSource()==btnNewButton_1){
                try {
                    new Department().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            } else if(ae.getSource()== btnNewButton_2){
                
                    new Employee().setVisible(true);
         
                    this.setVisible(false);
                
            } else if(ae.getSource()==  btnNewButton_3){
                new CustomerInfo().setVisible(true);
                this.setVisible(false);
                    
            } else if(ae.getSource()==  btnManagerInfo){
                             new ManagerInfo().setVisible(true);
         
                    this.setVisible(false);
            } else if(ae.getSource()== btnNewButton_4 ){
                try {
                    new CheckOut().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            } else if(ae.getSource()== btnNewButton_5){
                try {
                    new UpdateCheck().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            } else if(ae.getSource()==  btnNewButton_6 ){
              
                try {
                    new UpdateRoom().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            } else if(ae.getSource()== btnPickUpService){
                try {
                    new PickUp().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            }else if(ae.getSource()==  btnSearchRoom){
                try {
                    new SearchRoom().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Reception.class.getName()).log(Level.SEVERE, null, ex);
                }
                this.setVisible(false);
            }else if(ae.getSource()== btnNewButton_7){
                setVisible(false);
            }


        }
        
            
        public static void main(String[] args) {
		new Reception();
	}
}
